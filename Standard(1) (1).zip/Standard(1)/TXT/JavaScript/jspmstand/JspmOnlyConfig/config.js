System.config({
    map: {
        "core-js": "npm:core-js@1.2.7",
        "npm:gulp-task-listing@1.0.1": {
            "vm-browserify": "npm:vm-browserify@0.0.4"
        },
        "npm:babel-runtime@5.8.38": {
            "process": "npm:ansi-styles@3.2.1"
        },
        "npm:buffer@5.7.1": {
            "ieee754": "npm:ieee754@1.2.1"
        },
    }
});
