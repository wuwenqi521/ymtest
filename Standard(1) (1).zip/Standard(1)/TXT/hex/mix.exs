defmodule Plausible.MixProject do
  use Mix.Project
  
  defp deps do
    [
      {:alipay, "0.0.2"},
      {:cep_promise, "~> 0.0.3"}
    ]
  end
end
